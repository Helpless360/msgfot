from pyrogram import Client
from configs import configs

bot = Client(
    "bot",
    configs.api_id,
    configs.api_hash,
    bot_token=configs.bot_token,
    in_memory=True,
    plugins=dict(root="plugins")
)
